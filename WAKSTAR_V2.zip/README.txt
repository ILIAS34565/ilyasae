WAKSTAR V2 - Luxury Streetwear (Ready to deploy)

What's included:
- Simple React single-file app (App.jsx) and index.html for preview.
- public/hero.mp4 -> PLACEHOLDER file. Replace with your MP4 video (recommended: 1080x720, ~5-10s loop, muted).
- styles.css -> Tailwind-like utility classes via simple CSS (keeps it lightweight).
- Instructions to deploy on Vercel:
  1. Create a Vercel account at https://vercel.com
  2. Create a new project -> Upload -> select this ZIP
  3. Vercel will deploy and give you a URL (e.g. https://wakstar.vercel.app)
- Notes:
  - The placeholder hero.mp4 is a small text file. Replace it with a real MP4 video before uploading for the full visual effect.
  - The app is intentionally simple and self-contained so you can test locally or deploy directly.

Files:
- index.html
- App.jsx
- styles.css
- public/hero.mp4 (placeholder)
- README.txt
