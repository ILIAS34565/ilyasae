/*
  App.jsx - Simple single-file React/Preact app.
  Note: This file uses Preact + HTM via CDN for a zero-build demo.
  Vercel will serve this as a static site. For a production React app, integrate into create-react-app or Next.js.
*/
import { h, render, Component } from 'https://unpkg.com/preact@10.13.2?module';
import htm from 'https://unpkg.com/htm@3.1.1?module';
const html = htm.bind(h);

class App extends Component {
  render() {
    const products = [
      {id:1, slug:'canvas-hoodie', name:'هودي فاخر كانفاس', price:480, image:'images/1.jpg'},
      {id:2, slug:'silk-shirt', name:'قميص حريري ستريت', price:620, image:'images/2.jpg'},
      {id:3, slug:'women-blazer', name:'بليزر نسائي راقي', price:740, image:'images/3.jpg'}
    ];
    return html`
      <div class="site">
        <header class="site-header">
          <div class="brand">WAKSTAR</div>
          <nav class="nav">
            <a href="#shop">Shop</a>
            <a href="#about">About</a>
            <a href="#contact">Contact</a>
          </nav>
        </header>

        <section class="hero">
          <video class="hero-video" autoplay muted loop playsinline poster="hero-poster.jpg">
            <source src="public/hero.mp4" type="video/mp4" />
            <!-- If video missing, fallback to poster -->
          </video>
          <div class="hero-overlay"></div>
          <div class="hero-content">
            <h1>WAKSTAR</h1>
            <p>Wear the luxury street look — Fashion for the bold generation.</p>
            <div class="cta">
              <a class="btn" href="#shop">Shop Now</a>
              <a class="btn ghost" href="#about">Learn More</a>
            </div>
          </div>
        </section>

        <main id="shop" class="container">
          <h2>New Collection</h2>
          <div class="grid">
            ${products.map(p => html`
              <article class="card" key=${p.id}>
                <div class="img" style=${{'backgroundImage': `url(${p.image})`}}></div>
                <h3>${p.name}</h3>
                <p class="price">${p.price} MAD</p>
                <a class="view" href="#product-${p.slug}">View</a>
              </article>
            `)}
          </div>
        </main>

        <section id="about" class="about">
          <h3>About WAKSTAR</h3>
          <p>WAKSTAR blends premium materials with contemporary cuts to craft pieces that feel exclusive yet wearable.</p>
        </section>

        <footer class="footer">
          <p>© ${new Date().getFullYear()} WAKSTAR — Made with care in Morocco.</p>
        </footer>
      </div>
    `;
  }
}

render(html`<${App} />`, document.getElementById('root'));
